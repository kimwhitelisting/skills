# 프레젠테이션 편집

## 템플릿 기반 워크플로

기존 프리젠테이션을 템플릿으로 사용하는 경우:

1. **기존 슬라이드 분석**:
   ```bash
   python scripts/thumbnail.py template.pptx
   python -m markitdown template.pptx
   ```
레이아웃을 보려면 `thumbnails.jpg`을 검토하고, 자리 표시자 텍스트를 보려면 markitdown 출력을 검토하세요.

2. **슬라이드 매핑 계획**: 각 콘텐츠 섹션에 대해 템플릿 슬라이드를 선택합니다.

⚠️ **다양한 레이아웃 사용** — 단조로운 프레젠테이션은 일반적인 실패 모드입니다. 기본 제목 + 글머리 기호 슬라이드를 기본으로 사용하지 마세요. 적극적으로 찾아보십시오:
- 다중 열 레이아웃(2열, 3열)
- 이미지 + 텍스트 조합
- 텍스트 오버레이가 포함된 풀 블리드 이미지
- 견적 또는 설명선 슬라이드
- 섹션 구분선
- 통계/번호 콜아웃
- 아이콘 그리드 또는 아이콘 + 텍스트 행

**피해야 할 사항:** 모든 슬라이드에 텍스트가 많은 동일한 레이아웃을 반복합니다.

콘텐츠 유형을 레이아웃 스타일에 맞춥니다(예: 핵심 포인트 → 글머리 기호 슬라이드, 팀 정보 → 다중 열, 사용후기 → 인용 슬라이드).

3. **포장 풀기**: `python scripts/office/unpack.py template.pptx unpacked/`

4. **프레젠테이션 작성**(하위 에이전트가 아닌 직접 수행):
- 원하지 않는 슬라이드 삭제(`<p:sldIdLst>`에서 제거)
- 재사용하고 싶은 중복 슬라이드 (`add_slide.py`)
- `<p:sldIdLst>`에서 슬라이드 재정렬
- **5단계 이전에 모든 구조 변경을 완료하세요**

5. **콘텐츠 편집**: 각 `slide{N}.xml`의 텍스트를 업데이트합니다.
**가능한 경우 여기에서 하위 에이전트를 사용하세요** — 슬라이드는 별도의 XML 파일이므로 하위 에이전트가 동시에 편집할 수 있습니다.

6. **깨끗함**: `python scripts/clean.py unpacked/`

7. **팩**: `python scripts/office/pack.py unpacked/ output.pptx --original template.pptx`

---

## 스크립트

| 스크립트 | 목적 |
|--------|---------|
| `unpack.py` | PPTX 추출 및 예쁘게 인쇄하기 |
| `add_slide.py` | 슬라이드를 복제하거나 레이아웃에서 만들기 |
| `clean.py` | 고아 파일 제거 |
| `pack.py` | 유효성 검사를 통해 다시 포장 |
| `thumbnail.py` | 슬라이드의 시각적 그리드 만들기 |

### unpack.py

```bash
python scripts/office/unpack.py input.pptx unpacked/
```

PPTX를 추출하고 XML을 예쁘게 인쇄하고 스마트 따옴표를 이스케이프합니다.

### add_slide.py

```bash
python scripts/add_slide.py unpacked/ slide2.xml      # Duplicate slide
python scripts/add_slide.py unpacked/ slideLayout2.xml # From layout
```

`<p:sldId>`을 인쇄하여 원하는 위치의 `<p:sldIdLst>`에 추가합니다.

### clean.py

```bash
python scripts/clean.py unpacked/
```

`<p:sldIdLst>`에 없는 슬라이드, 참조되지 않은 미디어, 고아 관계를 제거합니다.

### pack.py

```bash
python scripts/office/pack.py unpacked/ output.pptx --original input.pptx
```

XML을 검증, 복구, 압축하고 스마트 인용을 다시 인코딩합니다.

### 썸네일.py

```bash
python scripts/thumbnail.py input.pptx [output_prefix] [--cols N]
```

슬라이드 파일 이름을 레이블로 사용하여 `thumbnails.jpg`을 만듭니다. 기본 열 3개, 그리드당 최대 12개.

**템플릿 분석에만 사용하세요**(레이아웃 선택). 시각적 QA의 경우 `soffice` + `pdftoppm`을 사용하여 전체 해상도의 개별 슬라이드 이미지를 만듭니다.
SKILL.md를 참조하세요.

---

## 슬라이드 작업

슬라이드 순서는 `ppt/presentation.xml` → `<p:sldIdLst>` 입니다.

**재순서**: `<p:sldId>` 요소를 재정렬합니다.

**삭제**: `<p:sldId>`을 제거한 다음 `clean.py`을 실행합니다.

**추가**: `add_slide.py`을 사용하세요. 슬라이드 파일을 수동으로 복사하지 마십시오. 스크립트는 수동 복사에서 누락된 메모 참조, Content_Types.xml
및 관계 ID를 처리합니다.

---

## 콘텐츠 편집

**하위 에이전트:** 가능한 경우 여기에서 사용하세요(4단계 완료 후). 각 슬라이드는 별도의 XML 파일이므로 하위 에이전트가 동시에 편집할 수 있습니다. 하위 에이전트에
대한 프롬프트에 다음을 포함합니다.
- 편집할 슬라이드 파일 경로
- **"모든 변경 사항에 편집 도구를 사용하세요"**
- 아래의 서식 규칙과 일반적인 함정

각 슬라이드에 대해 다음을 수행합니다.
1. 슬라이드의 XML을 읽습니다.
2. 텍스트, 이미지, 차트, 아이콘, 캡션 등 모든 자리 표시자 콘텐츠를 식별합니다.
3. 각 자리 표시자를 최종 콘텐츠로 교체합니다.

**sed 또는 Python 스크립트가 아닌 편집 도구를 사용하십시오.** 편집 도구는 대체할 항목과 위치를 구체적으로 지정하여 더 나은 안정성을 제공합니다.

### 서식 규칙

- **모든 헤더, 부제목, 인라인 라벨을 굵게 표시**: `<a:rPr>`에 `b="1"`을 사용하세요. 여기에는 다음이 포함됩니다.
- 슬라이드 제목
- 슬라이드 내의 섹션 헤더
- 줄 시작 부분에 있는 인라인 라벨(예: "상태:", "설명:")
- **유니코드 글머리 기호(•)를 사용하지 마세요**: `<a:buChar>` 또는 `<a:buAutoNum>`과 함께 적절한 목록 형식을 사용하세요.
- **글머리 기호 일관성**: 글머리 기호가 레이아웃에서 상속되도록 합니다. `<a:buChar>` 또는 `<a:buNone>`만 지정하세요.

---

## 일반적인 함정

### 템플릿 적응

소스 콘텐츠에 템플릿보다 항목 수가 적은 경우:
- **여분의 요소를 완전히 제거**(이미지, 도형, 텍스트 상자), 텍스트만 지우지 마세요.
- 텍스트 내용을 지운 후 고립된 시각적 개체가 있는지 확인하세요.
- 시각적 QA를 실행하여 일치하지 않는 개수 파악

텍스트를 다른 길이의 콘텐츠로 바꾸는 경우:
- **짧은 교체**: 일반적으로 안전함
- **교체 기간이 길어짐**: 예기치 않게 넘치거나 포장될 수 있음
- 텍스트 변경 후 시각적 QA로 테스트
- 템플릿의 디자인 제약에 맞게 콘텐츠를 자르거나 분할하는 것을 고려하세요.

**템플릿 슬롯 ≠ 소스 항목**: 템플릿에는 팀 구성원이 4명, 소스에는 사용자가 3명인 경우 텍스트뿐만 아니라 4번째 구성원의 전체 그룹(이미지 + 텍스트 상자)을
삭제합니다.

### 다중 항목 콘텐츠

소스에 여러 항목(번호가 매겨진 목록, 여러 섹션)이 있는 경우 각각에 대해 별도의 `<a:p>` 요소를 만듭니다. **절대 하나의 문자열로 연결하지 마세요**.

**❌ 틀렸음** — 한 단락의 모든 항목:
```xml
<a:p>
  <a:r><a:rPr .../><a:t>Step 1: Do the first thing. Step 2: Do the second thing.</a:t></a:r>
</a:p>
```

**✅ 정확함** — 굵은 머리글로 단락을 구분하세요:
```xml
<a:p>
  <a:pPr algn="l"><a:lnSpc><a:spcPts val="3919"/></a:lnSpc></a:pPr>
  <a:r><a:rPr lang="en-US" sz="2799" b="1" .../><a:t>Step 1</a:t></a:r>
</a:p>
<a:p>
  <a:pPr algn="l"><a:lnSpc><a:spcPts val="3919"/></a:lnSpc></a:pPr>
  <a:r><a:rPr lang="en-US" sz="2799" .../><a:t>Do the first thing.</a:t></a:r>
</a:p>
<a:p>
  <a:pPr algn="l"><a:lnSpc><a:spcPts val="3919"/></a:lnSpc></a:pPr>
  <a:r><a:rPr lang="en-US" sz="2799" b="1" .../><a:t>Step 2</a:t></a:r>
</a:p>
<!-- continue pattern -->
```

줄 간격을 유지하려면 원래 단락에서 `<a:pPr>`을 복사하세요. 헤더에 `b="1"`을 사용하세요.

### 스마트 인용문

포장 풀기/포장을 통해 자동으로 처리됩니다. 그러나 편집 도구는 둥근 따옴표를 ASCII로 변환합니다.

**따옴표가 포함된 새 텍스트를 추가할 때 XML 엔터티를 사용하세요.**

```xml
<a:t>the &#x201C;Agreement&#x201D;</a:t>
```

| 캐릭터 | 이름 | 유니코드 | XML 엔터티 |
|-----------|------|---------|------------|
| `“` | 왼쪽 큰따옴표 | U+201C | `&#x201C;` |
| `”` | 오른쪽 큰따옴표 | U+201D | `&#x201D;` |
| `‘` | 왼쪽 작은따옴표 | U+2018 | `&#x2018;` |
| `’` | 오른쪽 작은따옴표 | U+2019 | `&#x2019;` |

### 다른

- **공백**: 선행/후행 공백과 함께 `<a:t>`에 `xml:space="preserve"`을 사용합니다.
- **XML 구문 분석**: `xml.etree.ElementTree`이 아닌 `defusedxml.minidom` 사용(네임스페이스 손상)
